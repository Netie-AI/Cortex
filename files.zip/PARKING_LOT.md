# PARKING_LOT.md
**Deferred ideas. Do not build until the item's stated condition is met.**
**Add new ideas here, not to the active build plan.**

---

## Rule for this file
If you think of something during a build sprint and it's not the current feature, write it here with a one-line "why deferred" and a "condition to pick up." Do not context-switch. The parking lot is not the trash — everything here is real; it just has a queue position.

---

## Active parking lot

### P1 — Full Palantir ontology + AIP layer parity
**What:** Governed semantic objects (tables → named business objects with permissions + lineage + actions). The thing that makes Palantir's Foundry more than a query layer.
**Why deferred:** Requires a stable governed data spine first. H2 work.
**Condition:** DMS has 1+ paying clients and F1–F7 loop is production-hardened.

### P2 — WASM / Firecracker microVM production hardening
**What:** The `wasm_modules/` scaffold needs kernel-level isolation, cold-start benchmarks, and a security audit to be a real sandboxing claim.
**Why deferred:** Demo doesn't need production sandboxing. Enterprise/bank clients trigger this.
**Condition:** First enterprise (non-SME) client conversation starts.

### P3 — DAG token-saving optimization + Temporal durable execution
**What:** Parallel fan-out, speculative nodes, Temporal.io for durable long-running DAGs. The "better than Palantir for token cost" vision.
**Why deferred:** Basic DAG runs fine for the demo. Optimization is premature without real load.
**Condition:** 100+ DAG executions/day from real clients.

### P4 — respond.io-equivalent message endpoint / Closer auto-reply
**What:** An endpoint that receives inbound messages (WhatsApp/email/web), classifies sentiment, auto-drafts a reply (warmed, delayed ~seconds, no em-dash), scales to analyse customer needs. Closer-into-RUMA.
**Why deferred:** RUMA/Closer is the faster revenue wedge but requires its own dedicated sprint. DMS first.
**Condition:** DMS has one paying design partner OR Jian Hong explicitly decides to prioritise RUMA.
**Notes:** No em-dash in any generated reply. Delayed reply (2–5s artificial warmth). Tone scored by sentiment agent. Drafted reply always shown for human approval before send. The Closer persona lives in `packs/ruma/a2a/personas/closer.py` (planned).

### P5 — Full F2–F7 governed chat loop (if V0+V1 pilot lands without them)
**What:** Inbound message intake, chat space, classify, task suggest, compliance gate, skill capture, full security hardening.
**Why deferred:** Building V0→V1→pilot first to validate the warehouse angle before layering the full AI loop on top.
**Condition:** V0 + V1 are live at one warehouse AND they confirm the chat/task-suggest flow is what they want next. Do not build a loop nobody asked for.

### P6 — SQL automation / file-detect / Excel-CSV ingest pipeline
**What:** Watch a folder for new CSV/Excel drops, schema-infer, AI-assisted cleaning, entity resolution (Splink), standard output format, auto-copy block for Claude review.
**Why deferred:** V0 warehouse spine and V1 dimensioning first. Ingest is a separate but complementary track.
**Condition:** V1 gated. A design-partner warehouse has real dirty data they need to import.
**GitHub references to research when building:**
- `great-expectations/great_expectations` — data quality / expectations framework
- `dbt-labs/dbt-core` — transformation + lineage
- `moj-analytical-services/splink` — probabilistic record linkage on DuckDB, the right tool for cross-file entity resolution
- `cleanlab/cleanlab` — data-centric AI, label error detection
- `argilla-io/argilla` — human-in-the-loop data annotation
- Agentic cleaning wrappers to research: search GitHub for "agentic data cleaning" sorted by stars at build time — pick the most actively maintained, MIT/Apache licensed

### P7 — Annotation / labeling pipeline (for eval corpus and vision labels)
**What:** A structured pipeline to annotate warehouse photos (bounding boxes, item labels, shelf labels) and conversation turns (intent, sentiment ground truth). Use top-starred, latest available open models at build time.
**Why deferred:** Eval corpus needs at least 50 real warehouse interactions first. Can't label what doesn't exist.
**Condition:** One pilot warehouse is live and producing real interaction data.
**Notes:** Prefer on-box models for sovereignty. Research at build time: YOLO-series for detection, Grounding DINO for open-vocabulary detection, Label Studio for annotation UI (self-hosted).

### P8 — Claude / Cursor handoff protocol (automated)
**What:** A script that reads `STATUS.md` + `CHANGELOG_DMS.md` + last N lines of `pytest -q` and produces a clipboard-ready handoff block for pasting to a new Claude session or Cursor run.
**Why deferred:** `STATUS.md` + `CONTEXT.md` + `ARCHITECTURE.md` manually maintained covers this for now.
**Condition:** The manual update discipline breaks down (i.e., it's costing time, not saving it).
**Note:** The output format = paste `CONTEXT.md` + `STATUS.md` at the top of any new Claude chat. Keep total under 1500 tokens. That's the protocol until automated.

### P9 — respond.io as a Cortex endpoint (full integration)
**What:** Cortex as a drop-in respond.io alternative — receive messages from WhatsApp/email/web, score sentiment, route, draft reply, generate leads, retain customers.
**Why deferred:** respond.io's existing user base has it; you need a clear "why switch" beyond features. The moat is the governed data + skill capture underneath, not the chat surface.
**Condition:** DMS has paying clients AND RUMA/Closer pilot has validated the sentiment + auto-draft loop. Then position Cortex-chat as "respond.io with a governed brain."

### P10 — Forward deployed engineer full playbook + training materials
**What:** A structured guide for the FDE role: discovery checklist, labeling guide, migration runbook, client training script, week-by-week onboarding for a new warehouse.
**Why deferred:** You need one real deployment first to know what the actual friction points are. A playbook written before the first deployment will be mostly wrong.
**Condition:** First paid warehouse pilot completes. Write the playbook from what actually happened, not from theory.

### P11 — Post-quantum crypto readiness
**What:** NIST 2024 standardized ML-KEM (Kyber) / ML-DSA (Dilithium). Note the migration path for the F1 ledger signing key and the F7 encryption layer.
**Why deferred:** No enterprise/bank client demanding crypto-agility yet. AES-256-GCM and Ed25519 are fine.
**Condition:** First regulated-industry (bank, insurance, government) client conversation begins.

### P12 — Company central brain / everyone contributes files
**What:** A shared, governed document store where all team members drop files (policies, SOPs, supplier docs, contracts) and the AI indexes them for retrieval. The "company memory" vision.
**Why deferred:** Need F2 (governed chat) + F4 (task suggest) + RAG wired first — that's the technical spine. And you need a team/client before "everyone" contributes.
**Condition:** F2–F6 loop is live at one client AND there are at least 3 people using the system regularly.

### P13 — Blockchain / Web3 / Talkie / ASA / AIM / NetieX / Vanguard
**Why deferred:** Each is a standalone company's worth of work. None of them earn revenue in the next 90 days. The PRD exists; execution waits for DMS to be profitable.
**Condition:** H2 — DMS is profitable, team exists, capital is available.

---

## How to move something out of the parking lot
1. The stated condition is met.
2. Jian Hong or a gate with Claude explicitly moves it to the active build plan.
3. Add it to `docs/dms/BUILD_PLAN.md` or create a new vertical plan doc.
4. Update `STATUS.md`.
Never move a parked item into active build mid-sprint. Finish the current feature first.
