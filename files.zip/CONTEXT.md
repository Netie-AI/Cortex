# CONTEXT.md — Netie / CortexOS / DMS Brain
**Paste this at the start of any new Claude session or Cursor planning run.**
**Keep it under 800 tokens. Update after every major decision.**

---

## What this is
Netie is a forward-deployed AI platform. The current build focus is **DMS Brain** — a governed AI layer for warehouse/logistics SMEs. The substrate is **CortexOS** (open-source agentic runtime). The vertical logic lives in `packs/dms/`. The whole thing runs on the operator's own hardware (sovereign, data never leaves the box).

## Repo shape
```
Cortex/
├── CortexOS/          ← canonical runtime (DAG, compliance, routing, API)
├── netie/             ← import alias shim only (do not add logic here)
├── packs/dms/         ← DMS vertical: rules, vision, tasks, compliance YAMLs
├── demo/dms-ui/       ← Next.js 14 chat + warehouse UI (current demo)
├── demo/run_demo.ps1  ← one-command demo (fix seed path bug first)
├── docs/              ← all plans, gates, strategy
│   ├── dms/BUILD_PLAN.md, POSITIONING.md, VISION_GOVERNANCE.md, SUPERVISOR_GATE.md
│   └── strategy/NETIE_CORTEX_MASTER_PLAN.md
├── .cursor/           ← rules (5 .mdc), skills (3), AGENTS.md, hooks
├── STATUS.md          ← current build state (read first)
├── CHANGELOG_DMS.md   ← agent appends after each feature
└── PARKING_LOT.md     ← deferred ideas, do not build yet
```

## Key architectural decisions (locked)
- **Pack architecture:** `PACK=dms` env var selects the vertical at runtime. One CortexOS, many packs. Do not hardcode vertical logic in CortexOS/.
- **AI tier discipline:** T0 (embedders/classifiers, CPU) → T1 (small local LLM) → T2 (mid local LLM) → T3 = BIG_API_PLACEHOLDER (router-resolved). Hot loops T0/T1/T2 only. T3 for compliance final-check, complex negotiation, birthday rapport, eval judge — nothing else.
- **Deterministic compliance gate (F5):** LLMs extract fields; rules fire on structured data. LLM never decides pass/fail. Verdicts are deterministic.
- **Audit ledger (F1):** append-only, SHA-256 hash-chained. No update/delete path. Currently SQLite (demo); must move to Postgres + serialized append before real customer data.
- **PII gate (F7):** no PII may reach any LLM prompt. Redact at the choke-point before prompt-building. This is the single most important security control.
- **Vision (V-series):** suggestions + confidence gate, never auto-commit. Generation model ≠ measurement model. No generation model in any measurement path.
- **Forward deployment is the moat**, not the RAG. The FDE wires the operation around the system; that's what prevents churn.

## What is NOT in scope right now
- Rip-and-replace WMS pitch to Bursa-listed logistics players (they already have WMS)
- Full Palantir AIP/ontology parity
- WASM sandboxing hardening to production grade
- DAG token optimization
- respond.io / auto-reply endpoint
- RUMA/Closer wedge
- Blockchain / Web3 / Talkie / ASA / AIM (all parked)
→ Full list in `PARKING_LOT.md`

## FastAPI hard rules
- NO `from __future__ import annotations` in any FastAPI/Pydantic module
- ALL Pydantic models hoisted to module level
- `Request` imported from `starlette.requests` at module level
- Existing tests are sacred — new code adds new tests, never modifies old ones

## Placeholder tokens (never replace in committed code)
`BIG_API_PLACEHOLDER`, `EMBEDDER_MODEL`, `RERANKER_MODEL`, `WHATSAPP_BSP`, `DEPTH_SOURCE`, `VISION_MODEL`, `JUDGMENT_CLASSIFIER_VERSION`, `COMPLIANCE_RULE_VERSION`

## Current test baseline
`pytest -q` → 73 passed, 1 skipped (apscheduler not installed, expected)

## Cursor workflow
1. Read `STATUS.md` first
2. Dispatch one feature via `dms-subagent-dispatch`
3. Subagent plans → stops for review → implements → tests → `CHANGELOG_DMS.md`
4. Run `dms-claude-gate` → paste packet to Claude
5. Gate cleared by Claude → dispatch next feature
**Never skip the Claude gate. Never parallelize dependent features.**

## Claude gate schedule
- Gate V0 ✅ PASSED 2026-06-25
- Gate V1 → pending (V1 dimensioning)
- Gates V2, V3, F1-hardening, F2, F3, F4, F5, F6, F7 → after respective features
