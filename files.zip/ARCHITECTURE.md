# ARCHITECTURE.md — CortexOS + DMS Brain
**Current state is clearly marked. Planned/partial is marked. Do not present planned as shipped.**

---

## 1. System layers

```
┌─────────────────────────────────────────────────────┐
│  CLIENT LAYER                                       │
│  demo/dms-ui/ (Next.js 14 App Router)               │
│  Chat pane · Warehouse view · Query panel           │
└─────────────────────┬───────────────────────────────┘
                      │ HTTP + WebSocket
┌─────────────────────▼───────────────────────────────┐
│  API LAYER (FastAPI + uvicorn)                      │
│  CortexOS/api/  +  CortexOS/api/warehouse_routes.py │
│  PACK=dms selects vertical at startup               │
└──────┬──────────────┬───────────────────────────────┘
       │              │
┌──────▼──────┐  ┌────▼──────────────────────────────┐
│  DMS PACK   │  │  CortexOS RUNTIME                 │
│  packs/dms/ │  │  dag_engine/ · compliance/ ·      │
│  vision/    │  │  routing/ · rag/ · personality/   │
│  audit/     │  │  security/ · a2a/ · nlp/           │
│  tasks/     │  │                                   │
│  skills/    │  │  [most modules: planned/partial]  │
└──────┬──────┘  └────┬──────────────────────────────┘
       │              │
┌──────▼──────────────▼───────────────────────────────┐
│  DATA LAYER                                         │
│  DuckDB (analytics, demo)                           │
│  Supabase / Postgres (ops, auth, RLS)               │
│  SQLite (F1 ledger — demo only, move to Postgres)   │
│  Qdrant (vector store — planned)                    │
└─────────────────────────────────────────────────────┘
```

---

## 2. What is actually built (honest inventory)

### CortexOS runtime — current state
| Module | State | Notes |
|---|---|---|
| Pack loader (`load_pack()`, PACK env var) | ✅ Shipped | |
| DAG engine core | ⚠️ Partial | Basic DAG runner; Temporal durable execution, parallel fan-out, speculative nodes not yet wired |
| Cost ledger | ⚠️ Partial | Schema exists; per-node write not fully instrumented |
| Compliance engine (YAML→Python rules) | ✅ Shipped | Deterministic, vertical-agnostic; DMS rules in `packs/dms/` |
| Multi-tier model routing T0–T3 | ⚠️ Partial | `model_router.py` exists; JM judgment model is rules-v0 only |
| Hybrid RAG (BM25 + dense + reranker) | ⚠️ Partial | Architecture defined; Qdrant + retriever not wired to demo |
| WASM sandboxing | ⚠️ Partial | Scaffold in `wasm_modules/`; not production-hardened |
| A2A protocol | 📋 Planned | Spec in `docs/`; not implemented |
| Personality / timing / memory | 📋 Planned | RUMA vertical; parked |
| Eval harness | 📋 Planned | |

### DMS pack — current state
| Feature | State | Gate |
|---|---|---|
| F1 audit ledger (hash-chained, append-only) | ✅ Shipped (SQLite) | V0 PASS |
| F7 EXIF strip / photo sanitize | ✅ Shipped | V0 PASS |
| V0 warehouse spine (location tree, QR, intake, scan-move) | ✅ Shipped | V0 PASS |
| V1 dimensioning + free-space | 🔄 In progress | Gate V1 pending |
| F2 governed chat / inbox | 📋 Next after V1 | |
| F3 intent + sentiment classify | 📋 Planned | |
| F4 task suggest + learn | 📋 Planned | |
| F5 compliance gate on tasks | 📋 Planned | |
| F6 skill capture (consented, opt-in) | 📋 Planned | |
| F7 full (AES-GCM, RLS, PII redact, secrets) | 📋 Planned | Before real data |
| V2 slotting prediction | 📋 Planned | After V1 + pilot |
| V3 vision movement + map | 📋 Planned | Frontier, last |

### Demo layer
| Component | State |
|---|---|
| Next.js 14 chat + query UI | ✅ Running |
| Warehouse view (V0) | ✅ Running |
| `run_demo.ps1` end-to-end | ⚠️ Partial — seed crashes (`packs` path bug) |
| DuckDB seeded (25k rows, 6 tables) | ✅ |
| API health endpoint | ✅ |

---

## 3. What is NOT built (do not present as built)

- Full Palantir ontology layer (governed semantic objects with actions + permissions)
- AIP-equivalent LLM-over-governed-data with full lineage
- Production-grade WASM sandboxing / Firecracker microVM isolation
- Temporal.io durable execution
- Hash-chained ledger on Postgres with concurrent-append serialization (SQLite demo only)
- Qdrant live + BM25 hybrid RAG wired to demo
- F2–F7 chat/task/compliance/skill/security loop
- Vision model inference (V1+)
- Any V2/V3 features

---

## 4. Data flow (V0, what's working today)

```
FDE defines location tree (zones/racks/bins)
        │
        ▼ POST /dms/warehouse/locations
     location record + qr_token generated
        │
        ▼ Print QR label → stick to physical bin
        
Intake new item:
  POST /dms/items/intake { sku, label, location_code, photo }
        ├─► EXIF GPS stripped (F7 minimal)
        ├─► item record created, photo stored on-box
        ├─► F1 ledger: 'item.intake' appended (hash-chained)
        └─► item.current_location_id set

Scan item to new bin:
  POST /dms/movements/scan { item_id, to_location_qr }
        ├─► item.current_location_id updated
        ├─► movement record inserted
        └─► F1 ledger: 'item.moved' appended

Query the warehouse:
  NL query → sqlglot guardrail → DuckDB SELECT → result
```

---

## 5. Tech stack (actual, no aspirational bloat)

| Layer | Tech | State |
|---|---|---|
| Backend runtime | FastAPI + uvicorn | ✅ |
| Analytics query | DuckDB | ✅ |
| Ops DB | Supabase / Postgres | ✅ (Postgres migration ready; Supabase auth wired) |
| Audit ledger | SQLite → Postgres (todo) | ⚠️ |
| Frontend | Next.js 14 App Router | ✅ |
| SQL guardrail | sqlglot (SELECT-only) | ✅ |
| Compliance engine | YAML→Python, deterministic | ✅ |
| Photo handling | Pillow (EXIF strip) | ✅ |
| QR generation | `qrcode` lib | ✅ |
| Embedder | BGE-M3 via EMBEDDER_MODEL placeholder | 📋 |
| Vector store | Qdrant via placeholder | 📋 |
| Vision inference | VISION_MODEL placeholder | 📋 |
| Depth source | DEPTH_SOURCE placeholder | 📋 |
| Secrets | Currently env vars; SOPS+age planned | ⚠️ |

---

## 6. CortexOS gap vs. Palantir AIP (honest)

| Palantir capability | CortexOS today | Gap |
|---|---|---|
| Ontology (governed semantic objects) | Not built | Large — planned as H2 |
| Data integration + lineage | Partial (DuckDB + clean pipeline) | Medium |
| AIP (LLM over governed data) | Query routing + sqlglot guardrail | Partial — no full lineage |
| Agent orchestration | DAG engine (basic) | Medium |
| Governance / audit | F1 ledger (demo-grade) | Partial → harden for prod |
| Access control | RBAC + RLS (in migration) | Partial |
| Enterprise SSO | Supabase auth | Basic |
| WASM / microVM sandboxing | Scaffold only | Large |

**Palantir-parity is H2/H3. Do not position DMS as Palantir-equivalent today. Position as: governed AI layer for warehouse SMEs that beats Excel and layers on top of existing WMS.**

---

## 7. SQL automation / ingest pipeline — planned spec

When ready to build (after V1), the ingest module goes in `packs/dms/ingest/`:
- **File watcher:** detect new CSV/Excel drops in a watched folder
- **Schema inference:** detect column types, candidate join keys, mismatches
- **AI-assisted cleaning:** T1/T2 proposes rules → human approves → deterministic engine applies (AI proposes, deterministic executes — the established pattern)
- **Entity resolution:** Splink (probabilistic record linkage, runs on DuckDB) for cross-file deduplication
- **Standard output format:** every cleaned dataset writes to a canonical schema (`dms_ingest_output`) with provenance columns (source_file, cleaned_at, rule_applied)
- **Auto-copy to Claude:** a `scripts/export_for_review.py` that renders the last N ingest results + annotations into a clipboard-ready markdown block for Claude review
See `PARKING_LOT.md` for the GitHub references to research when building this.
