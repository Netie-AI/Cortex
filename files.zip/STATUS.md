# STATUS.md
**Last updated:** 2026-06-25 | **Gate:** V0 PASSED → V1 in progress
**Rule:** This file is updated by the agent or Jian Hong after every gate. Never let it go stale. A new Claude or Cursor session reads this first.

---

## Current state at a glance

| Layer | Status | Gate |
|---|---|---|
| CortexOS runtime (DAG, pack loader, compliance substrate) | ✅ Stable | — |
| DMS pack (PACK=dms loads clean) | ✅ Stable | — |
| Demo script (`run_demo.ps1`) | ⚠️ Partial — API+UI up, seed crashes on `packs` import | Fix before V1 |
| F1 audit ledger (SQLite, demo-grade) | ✅ Shipped | V0 PASS |
| F7 EXIF strip (photo sanitize) | ✅ Shipped | V0 PASS |
| V0 warehouse spine (location tree, QR, intake, scan-move) | ✅ Shipped | V0 PASS |
| F1 Postgres ledger + concurrent-append lock | ⚠️ Deferred — migration exists, not wired | Before real customer data |
| V1 dimensioning (reference-marker depth, free-space) | 🔄 Next | Gate V1 pending |
| F2 governed chat / inbox | 📋 Planned | After V1 |
| F3 classify (intent + sentiment, local T0/T1) | 📋 Planned | After F2 |
| F4 task suggest + learn | 📋 Planned | After F3 |
| F5 compliance gate on tasks | 📋 Planned | After F4 |
| F6 skill capture | 📋 Planned | After F5 |
| F7 full security hardening (encryption, RLS, PII) | 📋 Planned | Before real data |
| V2 slotting prediction | 📋 Planned | After V1 + pilot |
| V3 vision movement + map | 📋 Planned | Frontier, last |

## Test baseline
```
pytest -q → 73 passed, 1 skipped
Skipped: test_weekly_summarizer_registers_on_scheduler (apscheduler not installed)
```

## Known debt (fix before stated milestone)
| Debt | Fix | Milestone |
|---|---|---|
| `seed_warehouse.py` crashes — `packs` not on path | Add `sys.path.insert` or fix `run_demo.ps1` CWD | Before V1 |
| F1 ledger on SQLite, not Postgres | Wire Supabase migration + serialized-append lock | Before first real customer data |
| `PACK=ruma` default in conftest (was masking PACK=dms compliance tests) | Already fixed in Gate 0 | Done |

## Active feature in progress
**V1 dimensioning** — Cursor subagent dispatched per `docs/dms/VISION_GOVERNANCE.md`.
Anti-scope: no auto-commit below confidence, no generation model in measurement path, F5 gate on oversize/high-value items.

## Next three moves (in order)
1. Fix demo seed crash → verify `run_demo.ps1` runs end-to-end
2. Ship V1 → Gate V1 with Claude
3. Decide: ship V2 slotting OR begin F2 chat intake — whichever one paying warehouse prospect needs first

---

## Short-term goal (H1, 0–12 months)
1–3 paying SME warehouse design partners on V0 + governed chat. FDE setup fees. One case study on video. Revenue before features.

## Long-term goal (H2–H3)
H2: Layer on mid-market WMS, V1/V2 vision, RUMA Closer wedge.
H3: Dual-brain + consented skill capture + goal-driven planning.
Full detail: `docs/strategy/NETIE_CORTEX_MASTER_PLAN.md`.

## Key design constraints (do not violate)
- No rip-and-replace WMS pitch to listed Bursa players → layer-on-top or greenfield SME only
- No auto-commit of any vision-derived fact below confidence + F5 gate
- No PII in any LLM prompt — always redact first (F7)
- No BIG_API in hot loops — T0/T1/T2 only per-message
- All writes → F1 ledger. All sensitive data → encrypted at rest (before real customer data)
- Cursor subagents: sequential, one feature per run, Claude gate between each
